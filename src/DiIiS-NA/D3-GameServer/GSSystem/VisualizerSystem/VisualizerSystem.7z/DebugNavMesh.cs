﻿using DiIiS_NA.GameServer.Core.Types.QuadTrees;
using DiIiS_NA.GameServer.GSSystem.MapSystem;
using DiIiS_NA.GameServer.GSSystem.PlayerSystem;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System;
using System.Collections;
using DiIiS_NA.GameServer.GSSystem.ActorSystem;

namespace DiIiS_NA.GameServer.GSSystem.VisualizerSystem
{
    public class ConcurrentList<T> : IList<T>, IList
    {
        private readonly List<T> underlyingList = new List<T>();
        private readonly object syncRoot = new object();
        private readonly ConcurrentQueue<T> underlyingQueue;
        private bool requiresSync;
        private bool isDirty;

        public ConcurrentList()
        {
            underlyingQueue = new ConcurrentQueue<T>();
        }

        public ConcurrentList(IEnumerable<T> items)
        {
            underlyingQueue = new ConcurrentQueue<T>(items);
        }

        private void UpdateLists()
        {
            if (!isDirty)
                return;
            lock (syncRoot)
            {
                requiresSync = true;
                T temp;
                while (underlyingQueue.TryDequeue(out temp))
                    underlyingList.Add(temp);
                requiresSync = false;
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.GetEnumerator();
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Add(T item)
        {
            if (requiresSync)
                lock (syncRoot)
                    underlyingQueue.Enqueue(item);
            else
                underlyingQueue.Enqueue(item);
            isDirty = true;
        }

        public int Add(object value)
        {
            if (requiresSync)
                lock (syncRoot)
                    underlyingQueue.Enqueue((T)value);
            else
                underlyingQueue.Enqueue((T)value);
            isDirty = true;
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.IndexOf((T)value);
            }
        }

        public bool Contains(object value)
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.Contains((T)value);
            }
        }

        public int IndexOf(object value)
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.IndexOf((T)value);
            }
        }

        public void Insert(int index, object value)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.Insert(index, (T)value);
            }
        }

        public void Remove(object value)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.Remove((T)value);
            }
        }

        public void RemoveAt(int index)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.RemoveAt(index);
            }
        }

        T IList<T>.this[int index]
        {
            get
            {
                lock (syncRoot)
                {
                    UpdateLists();
                    return underlyingList[index];
                }
            }
            set
            {
                lock (syncRoot)
                {
                    UpdateLists();
                    underlyingList[index] = value;
                }
            }
        }

        object IList.this[int index]
        {
            get { return ((IList<T>)this)[index]; }
            set { ((IList<T>)this)[index] = (T)value; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool IsFixedSize
        {
            get { return false; }
        }

        public void Clear()
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.Clear();
            }
        }

        public bool Contains(T item)
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.Contains(item);
            }
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.CopyTo(array, arrayIndex);
            }
        }

        public bool Remove(T item)
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.Remove(item);
            }
        }

        public void CopyTo(Array array, int index)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.CopyTo((T[])array, index);
            }
        }

        public int Count
        {
            get
            {
                lock (syncRoot)
                {
                    UpdateLists();
                    return underlyingList.Count;
                }
            }
        }

        public object SyncRoot
        {
            get { return syncRoot; }
        }

        public bool IsSynchronized
        {
            get { return true; }
        }

        public int IndexOf(T item)
        {
            lock (syncRoot)
            {
                UpdateLists();
                return underlyingList.IndexOf(item);
            }
        }

        public void Insert(int index, T item)
        {
            lock (syncRoot)
            {
                UpdateLists();
                underlyingList.Insert(index, item);
            }
        }
    }
    /*
    public class DebugNavMesh
    {
        public World World { get; private set; }
        public Player Player { get; private set; }
        public RectangleF Bounds { get { return World.QuadTree.RootNode.Bounds; } }

        public ConcurrentList<Scene> MasterScenes { get; private set; }
        public ConcurrentList<Scene> SubScenes { get; private set; }
        public ConcurrentList<RectangleF> UnWalkableCells { get; private set; }
        public ConcurrentList<RectangleF> WalkableCells { get; private set; }
        public ConcurrentList<Player> Players { get; private set; }
        public ConcurrentList<Monster> Monsters { get; private set; }
        public ConcurrentList<NPC> NPCs { get; private set; }
        public ConcurrentList<Portal> Portals { get; private set; }

        public bool DrawMasterScenes;
        public bool DrawSubScenes;
        public bool DrawWalkableCells;
        public bool DrawUnwalkableCells;
        public bool DrawMonsters;
        public bool DrawNPCs;
        public bool DrawPlayers;
        public bool DrawPortals = true;
        public bool PrintSceneLabels;
        public bool FillCells;
        public bool DrawPlayerProximityCircle;
        public bool DrawPlayerProximityRectangle;

        private readonly Pen _masterScenePen = new Pen(Color.Black, 1.0f);
        private readonly Pen _subScenePen = new Pen(Color.DarkGray, 1.0f);
        private readonly Brush _unwalkableBrush = Brushes.Red;
        private readonly Pen _unwalkablePen = new Pen(Color.Red, 1.0f);
        private readonly Brush _walkableBrush = Brushes.Blue;
        private readonly Pen _walkablePen = new Pen(Color.Blue, 1.0f);
        private readonly Pen _playerProximityPen = new Pen(Brushes.DarkViolet, 2.0f);
        private readonly Font _sceneFont = new Font("Verdana", 7);

        public DebugNavMesh(World world, Player player = null)
        {
            this.World = world;
            this.Player = player;

            this._subScenePen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;

            this.MasterScenes = new ConcurrentList<Scene>();
            this.SubScenes = new ConcurrentList<Scene>();
            this.UnWalkableCells = new ConcurrentList<RectangleF>();
            this.WalkableCells = new ConcurrentList<RectangleF>();
            this.Players = new ConcurrentList<Player>();
            this.Monsters = new ConcurrentList<Monster>();
            this.NPCs = new ConcurrentList<NPC>();
            this.Portals = new ConcurrentList<Portal>();
        }

        #region update

        public void Update(bool processObjectsInAllTheWorld)
        {
            this.MasterScenes.Clear();
            this.SubScenes.Clear();
            this.WalkableCells.Clear();
            this.UnWalkableCells.Clear();
            this.Players.Clear();
            this.Monsters.Clear();
            this.NPCs.Clear();

            var scenes = (processObjectsInAllTheWorld || this.Player == null)
                                        ? World.QuadTree.Query<Scene>(World.QuadTree.RootNode.Bounds)
                                        : this.Player.GetScenesInRegion();

            Parallel.ForEach(scenes, scene =>
            {
                if (scene.Parent == null)
                    this.MasterScenes.Add(scene);
                else
                    this.SubScenes.Add(scene);

                this.AnalyzeScene(scene);
            });

            var actors = (processObjectsInAllTheWorld || this.Player == null)
                        ? World.QuadTree.Query<Actor>(World.QuadTree.RootNode.Bounds)
                        : this.Player.GetActorsInRange();

            Parallel.ForEach(actors, actor =>
            {
                if (actor is Player)
                    this.Players.Add(actor as Player);
                else if (actor is NPC)
                    this.NPCs.Add(actor as NPC);
                else if (actor is Monster)
                    this.Monsters.Add(actor as Monster);
                else if (actor is Portal)
                    this.Portals.Add(actor as Portal);
            });
        }

        private void AnalyzeScene(Scene scene)
        {
            Parallel.ForEach(scene.NavZone.NavCells, cell =>
            {
                float x = scene.Position.X + cell.Min.X;
                float y = scene.Position.Y + cell.Min.Y;

                float sizex = cell.Max.X - cell.Min.X;
                float sizey = cell.Max.Y - cell.Min.Y;

                var rect = new RectangleF(x, y, sizex, sizey);

                // TODO: Feature request: Also allow drawing of NavCellFlags.NOSpawn, NavCellFlags.LevelAreaBit0, NavCellFlags.LevelAreaBit1 cells. /raist.

                if ((cell.Flags & DiIiS_NA.Core.MPQ.FileFormats.Scene.NavCellFlags.AllowWalk) != DiIiS_NA.Core.MPQ.FileFormats.Scene.NavCellFlags.AllowWalk)
                    UnWalkableCells.Add(rect);
                else
                    WalkableCells.Add(rect);
            });
        }

        #endregion

        #region drawing

        public Bitmap Draw()
        {
            // As quad-tree always has 4 quad-nodes beneath the root node, the quad node's area will be far larger then actual area covered by scenes.
            // We don't want to draw a bitmap that's as large as quad-tree's area, as it'll be consuming so much memory.
            // So instead find the rightMostScene and bottomMostScene and limit the drawed bitmaps size according. /raist.
            // TODO: We can even limit to leftMostScene and topMostScene because player-proximity rendering mode will be also containing large empty areas. /raist.

            Scene rightMostScene = null;
            Scene bottomMostScene = null;

            foreach (var scene in this.MasterScenes)
            {
                if (rightMostScene == null)
                    rightMostScene = scene;

                if (bottomMostScene == null)
                    bottomMostScene = scene;

                if (scene.Bounds.X + scene.Bounds.Width > rightMostScene.Bounds.X + rightMostScene.Bounds.Width)
                    rightMostScene = scene;

                if (scene.Bounds.Y + scene.Bounds.Height > bottomMostScene.Bounds.Y + bottomMostScene.Bounds.Height)
                    bottomMostScene = scene;
            }

            if (rightMostScene == null || bottomMostScene == null)
                return null;

            var maxX = (int)(rightMostScene.Bounds.X + rightMostScene.Bounds.Width) + 1;
            var maxY = (int)(bottomMostScene.Bounds.Y + bottomMostScene.Bounds.Height) + 1;

            var bitmap = new Bitmap(maxX, maxY, System.Drawing.Imaging.PixelFormat.Format16bppRgb555);

            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighSpeed;
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;

                graphics.FillRectangle(Brushes.LightGray, 0, 0, bitmap.Width, bitmap.Height);

                this.DrawShapes(graphics);

                if (this.PrintSceneLabels)
                    this.DrawLabels(graphics);

                graphics.Save();
            }

            return bitmap;
        }

        private void DrawShapes(Graphics graphics)
        {
            if (this.DrawMasterScenes)
            {
                foreach (var scene in this.MasterScenes)
                {
                    this.DrawScene(graphics, scene);
                }
            }

            if (this.DrawSubScenes)
            {
                foreach (var scene in this.SubScenes)
                {
                    this.DrawScene(graphics, scene);
                }
            }

            if (this.DrawWalkableCells)
                this.DrawWalkables(graphics);

            if (this.DrawUnwalkableCells)
                this.DrawUnwalkables(graphics);

            if (this.DrawMonsters)
            {
                foreach (var monster in this.Monsters)
                {
                    this.DrawActor(monster, graphics, Brushes.Green, 7);
                }
            }

            if (this.DrawNPCs)
            {
                foreach (var npc in this.NPCs)
                {
                    this.DrawActor(npc, graphics, Brushes.Orange, 7);
                }
            }

            if (this.DrawPlayers)
            {
                foreach (var player in this.Players)
                {
                    this.DrawActor(player, graphics, Brushes.DarkViolet, 7);
                }
            }

            if (this.DrawPortals)
            {
                foreach (var portal in this.Portals)
                {
                    this.DrawActor(portal, graphics, Brushes.Azure, 10);
                }
            }

            if (this.DrawPlayerProximityCircle)
                this.DrawProximityCircle(graphics);

            if (this.DrawPlayerProximityRectangle)
                this.DrawProximityRectangle(graphics);
        }

        private void DrawScene(Graphics graphics, Scene scene)
        {
            var rect = new Rectangle((int)scene.Bounds.Left, (int)scene.Bounds.Top, (int)scene.Bounds.Width, (int)scene.Bounds.Height);
            graphics.DrawRectangle(scene.Parent == null ? _masterScenePen : _subScenePen, rect);
        }

        private void DrawWalkables(Graphics graphics)
        {
            foreach (var cell in this.WalkableCells)
            {
                var rect = new Rectangle(new System.Drawing.Point((int)cell.Left, (int)cell.Top), new System.Drawing.Size((int)cell.Width, (int)cell.Height));

                if (this.FillCells)
                    graphics.FillRectangle(_walkableBrush, rect);
                else
                    graphics.DrawRectangle(_walkablePen, rect);
            }
        }

        private void DrawUnwalkables(Graphics graphics)
        {
            foreach (var cell in this.UnWalkableCells)
            {
                var rect = new Rectangle(new System.Drawing.Point((int)cell.Left, (int)cell.Top), new System.Drawing.Size((int)cell.Width, (int)cell.Height));

                if (this.FillCells)
                    graphics.FillRectangle(_unwalkableBrush, rect);
                else
                    graphics.DrawRectangle(_unwalkablePen, rect);
            }
        }

        private void DrawActor(Actor actor, Graphics graphics, Brush brush, int radius)
        {
            var rect = new Rectangle((int)actor.Bounds.X, (int)actor.Bounds.Y, (int)actor.Bounds.Width + radius, (int)actor.Bounds.Height + radius);
            graphics.FillEllipse(brush, rect);
        }

        private void DrawProximityCircle(Graphics graphics)
        {
            if (this.Player == null)
                return;

            var rect = new RectangleF(this.Player.Position.X - 100f,
                                      this.Player.Position.Y - 100f,
                                      100f * 2,
                                      100f * 2);

            graphics.DrawEllipse(this._playerProximityPen, rect);
        }

        private void DrawProximityRectangle(Graphics graphics)
        {
            if (this.Player == null)
                return;

            graphics.DrawRectangle(this._playerProximityPen,
                                   this.Player.Position.X - Actor.DefaultQueryProximityLenght / 2,
                                   this.Player.Position.Y - Actor.DefaultQueryProximityLenght / 2,
                                   Actor.DefaultQueryProximityLenght,
                                   Actor.DefaultQueryProximityLenght);
        }

        private void DrawLabels(Graphics graphics)
        {
            if (this.DrawMasterScenes)
            {
                foreach (var scene in this.MasterScenes)
                {
                    this.DrawSceneLabel(graphics, scene);
                }
            }

            if (this.DrawSubScenes)
            {
                foreach (var scene in this.SubScenes)
                {
                    this.DrawSceneLabel(graphics, scene);
                }
            }
        }

        private void DrawSceneLabel(Graphics graphics, Scene scene)
        {
            var stringRectangle = new RectangleF((float)scene.Bounds.Left, (float)scene.Bounds.Top, (float)scene.Bounds.Width, (float)scene.Bounds.Height);
            var drawFormat = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };

            if (!string.IsNullOrEmpty(scene.SceneSNO.Name))
                graphics.DrawString(scene.SceneSNO.Name, _sceneFont, scene.Parent == null ? Brushes.Black : Brushes.Gray, stringRectangle, drawFormat);
        }

        #endregion

        #region DumpMeshtoObj
        public void DumpNavMeshToObj()
        {
            //Renders all the walkable cells into a 2d model. Output in http://en.wikipedia.org/wiki/Wavefront_.obj_file

            List<System.Drawing.Point> Vertices = new List<System.Drawing.Point>();
            //List<RectangleF> Vertices = new List<RectangleF>();
            List<face3> faces = new List<face3>();
            System.IO.StreamWriter fs = new System.IO.StreamWriter("world.obj");
            foreach (var rect in this.WalkableCells)
            {
                Rectangle a;
                Vertices.Add(new Point((int)rect.Width, 0));
                Vertices.Add(new Point(0, 0));
                Vertices.Add(new Point(0, (int)rect.Height));
                Vertices.Add(new Point((int)rect.Width, (int)rect.Height));
                faces.Add(new face3(Vertices.Count - 3, Vertices.Count - 2, Vertices.Count - 1, Vertices.Count - 0));
            }
            foreach (var x in Vertices)
            {
                fs.WriteLine("v " + x.X + " " + 0 + " " + x.Y);
            }
            foreach (var x in faces)
            {
                fs.WriteLine("f " + (x.i0) + " " + (x.i3) + " " + (x.i2) + " " + (x.i1));
            }
            fs.Close();
        }
        public class face3
        {
            public int i0, i1, i2, i3;
            public face3(int i1, int i2, int i3, int i4)
            {
                this.i0 = i1;
                this.i1 = i2;
                this.i2 = i3;
                this.i3 = i4;
            }
        }
        #endregion
    }
    //*/
}
